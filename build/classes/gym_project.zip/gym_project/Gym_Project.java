/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gym_project;


import gym_project.view.AdminRegistration;
import gym_project.view.Dashboard;
import gym_project.view.EditMemberPage;
import gym_project.view.EditTrainerPage;
import gym_project.view.LoginPage;
import gym_project.view.MemberAttendace;
import gym_project.view.Membershipadd;
import gym_project.view.PaymentPage;
import gym_project.view.TrainerAdd;
import gym_project.view.TrainerAttendance;
import javax.swing.JFrame;



/**
 *
 * @author user
 */
public class Gym_Project extends JFrame {
    


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//       AdminRegistration ar = new AdminRegistration();
//       ar.setVisible(true);
        EditTrainerPage ss = new EditTrainerPage();
       
         ss.setVisible(true);
    }
    
}
